import psycopg2
from psycopg2 import pool

try:
    postgresql_pool = psycopg2.pool.ThreadedConnectionPool(
        5, 20,
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )

    if postgresql_pool:
        connection = postgresql_pool.getconn()
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM mobile")
            for row in cursor.fetchall():
                print(row)
            cursor.close()
            postgresql_pool.putconn(connection)

except (Exception, psycopg2.DatabaseError) as error:
    print("Ошибка при подключении к PostgreSQL", error)
finally:
    if postgresql_pool:
        postgresql_pool.closeall()
    print("Пул соединений PostgreSQL закрыт")