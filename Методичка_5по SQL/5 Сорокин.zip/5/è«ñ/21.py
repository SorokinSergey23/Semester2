import psycopg2
from psycopg2 import Error

params = {
    "user": "postgres",
    "password": "1111",
    "host": "127.0.0.1",
    "port": "5432",
    "database": "postgres_db"
}

try:
    connection = psycopg2.connect(**params)
    connection.autocommit = False
    with connection.cursor() as cursor:
        cursor.execute("SELECT price FROM itemstable WHERE itemid = 876")
        item_price = int(cursor.fetchone()[0])

        cursor.execute("SELECT balance FROM evallet WHERE userId = 23")
        new_balance = int(cursor.fetchone()[0]) - item_price
        cursor.execute("UPDATE evallet SET balance = %s WHERE userId = 23", (new_balance,))

        cursor.execute("SELECT balance FROM account WHERE accountId = 2236781258763")
        new_acc_balance = int(cursor.fetchone()[0]) + item_price
        cursor.execute("UPDATE account SET balance = %s WHERE accountId = 2236781258763", (new_acc_balance,))

        connection.commit()
        print("Транзакция успешно завершена")

except (Exception, Error) as error:
    print("Ошибка в транзакции", error)
    connection.rollback()
finally:
    if connection:
        connection.close()
        print("Соединение с PostgreSQL закрыто")