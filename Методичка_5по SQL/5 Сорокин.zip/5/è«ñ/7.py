import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )
    cursor = connection.cursor()

    insert_query = """INSERT INTO mobile (ID, MODEL, PRICE) VALUES
    (1, 'iPhone 12', 1000),
    (2, 'Google Pixel 2', 700),
    (3, 'Samsung Galaxy S21', 900),
    (4, 'Nokia', 800)"""

    cursor.execute(insert_query)
    connection.commit()

except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL:", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")