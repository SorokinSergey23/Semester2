import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )
    cursor = connection.cursor()

    insert_query = """INSERT INTO mobile (ID, MODEL, PRICE) VALUES (1, 'Iphone12', 1100)"""
    cursor.execute(insert_query)
    connection.commit()
    print("1 запись успешно вставлена")
    cursor.execute("SELECT * from mobile")
    print("Результат:", cursor.fetchall())

    update_query = """UPDATE mobile SET price = 1500 WHERE id = 1"""
    cursor.execute(update_query)
    connection.commit()
    print(cursor.rowcount, "запись успешно обновлена")
    cursor.execute("SELECT * from mobile")
    print("Результат:", cursor.fetchall())

    delete_query = """DELETE FROM mobile WHERE id = 1"""
    cursor.execute(delete_query)
    connection.commit()
    print(cursor.rowcount, "запись успешно удалена")
    cursor.execute("SELECT * from mobile")
    print("Результат:", cursor.fetchall())

except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")