from tkinter import *
from tkinter import ttk
from tkinter import filedialog

root = Tk()
root.title("METANIT.COM")
root.geometry("400x300")

text_editor = Text()
text_editor.pack(fill=BOTH, expand=1)

def open_file():
    filepath = filedialog.askopenfilename()
    if filepath:
        with open(filepath, "r") as file:
            text_editor.delete("1.0", END)
            text_editor.insert("1.0", file.read())

def save_file():
    filepath = filedialog.asksaveasfilename()
    if filepath:
        with open(filepath, "w") as file:
            file.write(text_editor.get("1.0", END))

ttk.Button(text="Открыть", command=open_file).pack(side=LEFT)
ttk.Button(text="Сохранить", command=save_file).pack(side=RIGHT)
root.mainloop()