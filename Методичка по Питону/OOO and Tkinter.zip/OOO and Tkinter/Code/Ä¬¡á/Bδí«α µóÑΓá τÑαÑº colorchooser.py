from tkinter import *
from tkinter import ttk
from tkinter import colorchooser

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

label = ttk.Label(text="Текст")
label.pack()

def select_color():
    color = colorchooser.askcolor()[1]
    label.config(foreground=color)

ttk.Button(text="Выбрать цвет", command=select_color).pack()
root.mainloop()