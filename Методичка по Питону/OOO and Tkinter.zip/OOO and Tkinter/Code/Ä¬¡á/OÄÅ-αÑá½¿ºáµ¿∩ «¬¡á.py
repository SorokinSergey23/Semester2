from tkinter import *
from tkinter import ttk

class Window(Tk):
    def __init__(self):
        super().__init__()
        self.title("Новое окно")
        self.geometry("250x200")
        ttk.Button(self, text="Закрыть", command=self.destroy).pack(anchor=CENTER, expand=1)

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")
ttk.Button(text="Создать окно", command=lambda: Window()).pack(anchor=CENTER, expand=1)
root.mainloop()