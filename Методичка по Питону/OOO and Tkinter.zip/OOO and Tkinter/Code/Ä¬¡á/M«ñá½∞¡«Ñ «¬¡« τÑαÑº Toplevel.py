from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def click():
    window = Toplevel()
    window.title("Диалоговое окно")
    window.geometry("250x200")
    window.grab_set()
    ttk.Button(window, text="Закрыть", command=window.destroy).pack(anchor=CENTER, expand=1)

ttk.Button(text="Открыть диалог", command=click).pack(anchor=CENTER, expand=1)
root.mainloop()