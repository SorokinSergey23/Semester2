from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

style = ttk.Style()
style.configure(
    "My.TLabel",
    font="helvetica 14",
    foreground="#004D40",
    padding=10,
    background="#B2DFDB"
)

label = ttk.Label(text="Hello World", style="My.TLabel")
label.pack(anchor=CENTER, expand=1)

root.mainloop()