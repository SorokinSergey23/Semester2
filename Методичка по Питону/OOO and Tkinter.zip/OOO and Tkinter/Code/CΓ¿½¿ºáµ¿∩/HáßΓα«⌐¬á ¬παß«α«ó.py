from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

ttk.Label(text="Hello World!", cursor="pencil").pack(anchor=CENTER, expand=1)

root.config(cursor="watch")

root.mainloop()