from tkinter import *

root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

check_var = BooleanVar()
check = Checkbutton(root, text="Согласен с условиями", 
                  variable=check_var)
check.pack(pady=10)

root.mainloop()