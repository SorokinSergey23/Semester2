from tkinter import *

root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

icon = PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Разработка графического приложения\93d8945b0e64404ae92b547edd6a36c8.png")
root.iconphoto(True, icon)

root.mainloop()