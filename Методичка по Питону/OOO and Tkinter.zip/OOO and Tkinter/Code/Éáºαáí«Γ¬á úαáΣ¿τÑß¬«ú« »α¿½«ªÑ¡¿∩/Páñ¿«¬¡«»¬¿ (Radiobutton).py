from tkinter import *

root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

radio_var = StringVar()
radio_var.set("option1")

Radiobutton(root, text="Вариант 1", variable=radio_var, 
           value="option1").pack()
Radiobutton(root, text="Вариант 2", variable=radio_var, 
           value="option2").pack()

root.mainloop()