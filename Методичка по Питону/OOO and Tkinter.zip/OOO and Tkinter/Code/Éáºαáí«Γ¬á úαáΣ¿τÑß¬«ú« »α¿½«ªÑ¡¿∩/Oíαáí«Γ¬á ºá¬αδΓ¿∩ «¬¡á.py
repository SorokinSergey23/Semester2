from tkinter import *
from tkinter import messagebox  
root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

def on_closing():
    if messagebox.askokcancel("Выход", "Вы уверены, что хотите выйти?"):
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()