from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

ttk.Progressbar(orient="vertical", length=100, value=40).pack(pady=5)

ttk.Progressbar(orient="horizontal", length=150, value=20).pack(pady=5)

root.mainloop()