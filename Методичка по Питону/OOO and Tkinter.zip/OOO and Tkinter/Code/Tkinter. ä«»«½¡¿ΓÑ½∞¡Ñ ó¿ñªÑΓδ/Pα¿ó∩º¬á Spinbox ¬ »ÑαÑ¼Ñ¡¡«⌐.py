from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

spinbox_var = StringVar(value=22)
label = ttk.Label(textvariable=spinbox_var)
label.pack(anchor=NW)

spinbox = ttk.Spinbox(
    from_=1.0, 
    to=100.0, 
    textvariable=spinbox_var
)
spinbox.pack(anchor=NW)

root.mainloop()