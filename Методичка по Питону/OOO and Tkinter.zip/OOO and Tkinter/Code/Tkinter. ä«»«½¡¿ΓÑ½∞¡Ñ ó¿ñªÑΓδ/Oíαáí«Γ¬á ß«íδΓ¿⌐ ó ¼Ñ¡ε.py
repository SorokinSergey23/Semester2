from tkinter import *
from tkinter import messagebox

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")
root.option_add("*tearOff", FALSE)

def edit_click():
    messagebox.showinfo("Info", "Нажата опция Edit")

main_menu = Menu()
main_menu.add_cascade(label="File")
main_menu.add_cascade(label="Edit", command=edit_click)
main_menu.add_cascade(label="View")

root.config(menu=main_menu)
root.mainloop()