import customtkinter

class FloatSpinbox(customtkinter.CTkFrame):
    def __init__(self, master, 
                 width: int = 100,
                 height: int = 32,
                 min_value: float = 0,
                 max_value: float = 100,
                 step: float = 1,
                 initial_value: float = 0,
                 **kwargs):
        super().__init__(master, width=width, height=height, **kwargs)
        
        self.min_value = min_value
        self.max_value = max_value
        self.step = step
        self.value = initial_value
        
        self.grid_columnconfigure((0, 2), weight=0)
        self.grid_columnconfigure(1, weight=1)

        self.button_decrease = customtkinter.CTkButton(
            self, text="-", width=height-6, height=height-6,
            command=self.decrease_value
        )
        self.button_decrease.grid(row=0, column=0, padx=(3, 0), pady=3)

        self.entry = customtkinter.CTkEntry(
            self, width=width-(2*height), height=height-6,
            justify="center"
        )
        self.entry.grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        self.entry.insert(0, str(initial_value))
        self.entry.bind("<KeyRelease>", self.validate_entry)

        self.button_increase = customtkinter.CTkButton(
            self, text="+", width=height-6, height=height-6,
            command=self.increase_value
        )
        self.button_increase.grid(row=0, column=2, padx=(0, 3), pady=3)

        self.button_decrease.configure(font=("Arial", 12))
        self.button_increase.configure(font=("Arial", 12))
    
    def decrease_value(self):
        new_value = self.value - self.step
        if new_value >= self.min_value:
            self.value = new_value
            self.entry.delete(0, "end")
            self.entry.insert(0, f"{self.value:.2f}")
    
    def increase_value(self):
        new_value = self.value + self.step
        if new_value <= self.max_value:
            self.value = new_value
            self.entry.delete(0, "end")
            self.entry.insert(0, f"{self.value:.2f}")
    
    def validate_entry(self, event):
        try:
            value = float(self.entry.get())
            if self.min_value <= value <= self.max_value:
                self.value = value
            else:
                self.entry.delete(0, "end")
                self.entry.insert(0, f"{self.value:.2f}")
        except ValueError:
            self.entry.delete(0, "end")
            self.entry.insert(0, f"{self.value:.2f}")
    
    def get(self):
        return self.value
    
    def set(self, value):
        if self.min_value <= value <= self.max_value:
            self.value = value
            self.entry.delete(0, "end")
            self.entry.insert(0, f"{self.value:.2f}")

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("Custom Spinbox Example")
        self.geometry("300x100")

        self.spinbox = FloatSpinbox(
            self, 
            width=150,
            min_value=0,
            max_value=10,
            step=0.5,
            initial_value=5
        )
        self.spinbox.pack(pady=20)

        self.button = customtkinter.CTkButton(
            self, text="Get Value", 
            command=lambda: print("Current value:", self.spinbox.get())
        )
        self.button.pack()

app = App()
app.mainloop()