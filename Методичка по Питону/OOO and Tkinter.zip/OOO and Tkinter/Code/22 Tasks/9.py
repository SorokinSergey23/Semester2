class SnowFlake:
    def __init__(self, size):
        self.size = size
        self.grid = self._create_snowflake()
    def _create_snowflake(self):
        grid = [['-' for _ in range(self.size)] for _ in range(self.size)]
        center = self.size // 2
        for i in range(self.size):
            grid[center][i] = '*'
            grid[i][center] = '*'
            grid[i][i] = '*'
            grid[i][self.size - 1 - i] = '*'
        return grid
    def thaw(self, steps=1):
        for _ in range(steps):
            if self.size <= 1:
                break
            self.size -= 2
            self.grid = [row[1:-1] for row in self.grid[1:-1]]
    def freeze(self, n=1):
        for _ in range(n):
            self.size += 2
            self.grid = [['-'] + row + ['-'] for row in self.grid]
            self.grid.insert(0, ['-' for _ in range(self.size)])
            self.grid.append(['-' for _ in range(self.size)])
            self._update_snowflake()
    def _update_snowflake(self):
        center = self.size // 2
        for i in range(self.size):
            self.grid[center][i] = '*'
            self.grid[i][center] = '*'
            self.grid[i][i] = '*'
            self.grid[i][self.size - 1 - i] = '*'
    def thicken(self):
        new_grid = [row.copy() for row in self.grid]
        for i in range(self.size):
            for j in range(self.size):
                if self.grid[i][j] == '*':
                    for di, dj in [(0,1), (1,0), (0,-1), (-1,0)]:
                        ni, nj = i + di, j + dj
                        if 0 <= ni < self.size and 0 <= nj < self.size:
                            new_grid[ni][nj] = '*'
        self.grid = new_grid
    def show(self):
        for row in self.grid:
            print(' '.join(row))
if __name__ == "__main__":
    sf = SnowFlake(5)
    print("Исходная снежинка:")
    sf.show()
    print("\nПосле оттаивания(1):")
    sf.thaw(1)
    sf.show()
    print("\nПосле замораживания(2):")
    sf.freeze(2)
    sf.show()
    print("\nПосле сгущения():")
    sf.thicken()
    sf.show()
    print("\nПосле оттаивания(2):")
    sf.thaw(2)
    sf.show()