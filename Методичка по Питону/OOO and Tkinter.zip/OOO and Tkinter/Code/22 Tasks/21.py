import math
class Vehicle:
    def __init__(self, x=0, y=0, angle=0):
        self.x = x
        self.y = y
        self.angle = angle
    def move(self, distance):
        rad = math.radians(self.angle)
        self.x += distance * math.cos(rad)
        self.y += distance * math.sin(rad)
    def turn(self, angle):
        self.angle = (self.angle + angle) % 360
    def get_position(self):
        return (self.x, self.y)
    def get_direction(self):
        return self.angle
    def __str__(self):
        return f"Позиция: ({self.x:.1f}, {self.y:.1f}), Направление: {self.angle}°"
class Bus(Vehicle):
    def __init__(self, x=0, y=0, angle=0):
        super().__init__(x, y, angle)
        self.passengers = 0
        self.money = 0
        self.fare = 20
    def enter(self, count=1):
        self.passengers += count
    def exit(self, count=1):
        self.passengers = max(0, self.passengers - count)
    def move(self, distance):
        super().move(distance)
        self.money += self.passengers * distance * self.fare
    def __str__(self):
        return (f"{super().__str__()}, "
                f"Пассажиров: {self.passengers}, "
                f"Денег: {self.money} руб.")
if __name__ == "__main__":
    car = Vehicle(10, 20, 45)
    print(car)
    car.move(10)
    print("После перемещения на 10 единиц:")
    print(car)
    car.turn(90)
    print("После поворота на 90 градусов:")
    print(car)
    car.move(5)
    print("После перемещения на 5 единиц:")
    print(car)
    print()
    bus = Bus(0, 0, 0)
    bus.enter(5)
    print(bus)
    bus.move(10)
    print("После поездки с пассажирами:")
    print(bus)
    bus.turn(90)
    bus.exit(3)
    bus.move(5)
    print("После поворота, выхода пассажиров и новой поездки:")
    print(bus)