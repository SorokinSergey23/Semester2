from datetime import datetime
class Post:
    def __init__(self, username, message):
        self.username = username
        self.message = message
        self.timestamp = datetime.now()
        self.likes = 0
        self.comments = []
    def add_like(self):
        self.likes += 1
    def add_comment(self, comment):
        self.comments.append(comment)
    def __str__(self):
        return (f"Автор: {self.username}\n"
                f"Время: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Лайков: {self.likes}\n"
                f"Текст: {self.message}\n"
                f"Комментарии ({len(self.comments)}): {self.comments}")
if __name__ == "__main__":
    post = Post("user123", "Мой первый пост в этой сети!")
    post.add_like()
    post.add_like()
    post.add_comment("Отличный пост!")
    post.add_comment("Согласен с автором")
    print(post)