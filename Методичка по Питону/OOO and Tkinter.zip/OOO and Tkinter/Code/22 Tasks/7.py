class Bus:
    def __init__(self, max_speed=90, capacity=30):
        self.speed = 0
        self.capacity = capacity
        self.max_speed = max_speed
        self.passengers = []
        self.seats = {i: None for i in range(1, capacity+1)}
    @property
    def has_empty_seats(self):
        return len(self.passengers) < self.capacity
    def board_passenger(self, passenger_name, seat_num=None):
        if not self.has_empty_seats:
            return False
        if seat_num is None:
            for num, occupant in self.seats.items():
                if occupant is None:
                    seat_num = num
                    break
        if seat_num not in self.seats or self.seats[seat_num] is not None:
            return False
        self.seats[seat_num] = passenger_name
        self.passengers.append(passenger_name)
        return True
    def disembark_passenger(self, passenger_name):
        if passenger_name not in self.passengers:
            return False
        for seat_num, name in self.seats.items():
            if name == passenger_name:
                self.seats[seat_num] = None
                break
        self.passengers.remove(passenger_name)
        return True
    def change_speed(self, delta):
        new_speed = self.speed + delta
        self.speed = max(0, min(new_speed, self.max_speed))
    def __contains__(self, passenger_name):
        return passenger_name in self.passengers
    def __iadd__(self, passenger_name):
        if isinstance(passenger_name, str):
            self.board_passenger(passenger_name)
        elif isinstance(passenger_name, (list, tuple)):
            for name in passenger_name:
                self.board_passenger(name)
        return self
    def __isub__(self, passenger_name):
        if isinstance(passenger_name, str):
            self.disembark_passenger(passenger_name)
        elif isinstance(passenger_name, (list, tuple)):
            for name in passenger_name:
                self.disembark_passenger(name)
        return self
    def __str__(self):
        return (f"Автобус (скорость: {self.speed}/{self.max_speed} км/ч, "
                f"пассажиров: {len(self.passengers)}/{self.capacity}, "
                f"свободные места: {self.has_empty_seats})")
if __name__ == "__main__":
    bus = Bus(max_speed=80, capacity=5)
    print(bus)
    print("\nПосадка пассажиров:")
    bus += "Поляков"
    bus += ["Страха", "Гладких"]
    print(bus)
    print("Пассажиры:", bus.passengers)
    print("Места:", bus.seats)
    print("\nПроверка наличия пассажиров:")
    print("Поляков в автобусе?", "Поляков" in bus)
    print("Гладких в автобусе?", "Гладких" in bus)
    print("\nВысадка пассажира:")
    bus -= "Страха"
    print(bus)
    print("Пассажиры:", bus.passengers)
    print("Места:", bus.seats)
    print("\nИзменение скорости:")
    bus.change_speed(50)
    print("Скорость после увеличения:", bus.speed)
    bus.change_speed(-20)
    print("Скорость после уменьшения:", bus.speed)
    bus.change_speed(100)
    print("Скорость при попытке превысить максимум:", bus.speed)
    print("\nПосадка на конкретное место:")
    bus.board_passenger("Павлов", 4)
    print("Места:", bus.seats)
    print("\nПопытка переполнения:")
    bus += ["Гладких", "Растворов", "Кириллов"]
    print(bus)
    print("Пассажиры:", bus.passengers)
    print("Места:", bus.seats)