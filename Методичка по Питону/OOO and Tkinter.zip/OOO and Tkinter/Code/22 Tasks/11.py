class Themes:
    def __init__(self, themes_list):
        self.themes = list(themes_list)
    def add_theme(self, value):
        self.themes.append(value)
    def shift_one(self):
        if len(self.themes) > 1:
            last = self.themes.pop()
            self.themes.insert(0, last)
    def reverse_order(self):
        self.themes.reverse()
    def get_themes(self):
        return tuple(self.themes)
    def get_first(self):
        return self.themes[0] if self.themes else None
print("Пример 1:")
tl = Themes(['weather', 'rain'])
tl.add_theme('warm')
print(tl.get_themes())
tl.shift_one()
print(tl.get_first())
print("\nПример 2:")
tl = Themes(['sun', 'feeding'])
tl.add_theme('cool')
tl.shift_one()
print(tl.get_first())
tl.reverse_order()
print(tl.get_themes())