class TArray:
    def __init__(self, *args):
        if len(args) == 0:
            self.size = 0
            self.data = []
        else:
            self.size = len(args)
            self.data = list(args)
    def __copy__(self):
        new_array = TArray()
        new_array.size = self.size
        new_array.data = self.data.copy()
        return new_array
    def input(self):
        self.size = int(input("Введите количество элементов: "))
        self.data = []
        for i in range(self.size):
            element = float(input(f"Введите элемент {i+1}: "))
            self.data.append(element)
    def output(self):
        print("Массив:", self.data)
    def find_max(self):
        return max(self.data) if self.size > 0 else None
    def find_min(self):
        return min(self.data) if self.size > 0 else None
    def sort(self):
        self.data.sort()
    def sum_elements(self):
        return sum(self.data)
    def __add__(self, element):
        new_array = self.__copy__()
        new_array.data.append(element)
        new_array.size += 1
        return new_array
    def __mul__(self, scalar):
        new_array = self.__copy__()
        new_array.data = [x * scalar for x in new_array.data]
        return new_array
    def __str__(self):
        return str(self.data)
if __name__ == "__main__":
    print("Создание массива с параметрами")
    arr1 = TArray(3, 1, 4, 1, 5, 9)
    arr1.output()
    print("\nПоиск максимума и минимума")
    print(f"Максимальный элемент: {arr1.find_max()}")
    print(f"Минимальный элемент: {arr1.find_min()}")
    print("\nСортировка массива")
    arr1.sort()
    arr1.output()
    print("\nСумма элементов")
    print(f"Сумма: {arr1.sum_elements()}")
    print("\nДобавление элемента с помощью оператора +")
    arr2 = arr1 + 2
    arr2.output()
    print("\nУмножение массива на скаляр с помощью оператора *")
    arr3 = arr1 * 3
    arr3.output()
    print("\nСоздание массива без параметров и ввод с клавиатуры")
    arr4 = TArray()
    arr4.input()
    arr4.output()