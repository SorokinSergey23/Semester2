class Robot:
    def __init__(self, x=0, y=0):
        self.x = min(max(0, x), 100)
        self.y = min(max(0, y), 100)
        self._path_history = [(self.x, self.y)]
    def move(self, commands):
        current_path = [(self.x, self.y)]
        for cmd in commands.upper():
            new_x, new_y = self.x, self.y
            if cmd == 'N' and self.y < 100:
                new_y += 1
            elif cmd == 'S' and self.y > 0:
                new_y -= 1
            elif cmd == 'E' and self.x < 100:
                new_x += 1
            elif cmd == 'W' and self.x > 0:
                new_x -= 1
            if (new_x, new_y) != (self.x, self.y):
                self.x, self.y = new_x, new_y
                current_path.append((self.x, self.y))
        self._path_history = current_path
        return [self.x, self.y]
    def path(self):
        return self._path_history.copy()
if __name__ == "__main__":
    robot = Robot(50, 50)
    print("Начальная позиция:", robot.path())   
    final_pos = robot.move("NNEESWWN")
    print("Конечная позиция:", final_pos)
    print("Весь путь:", robot.path())
    robot.move("WWWWWW")  
    print("После движения на запад:", robot.path())
    robot.move("SSSSSSSS")  
    print("После движения на юг:", robot.path())