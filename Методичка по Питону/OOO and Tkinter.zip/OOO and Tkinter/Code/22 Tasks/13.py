class Talking:
    def __init__(self, name):
        self.name = name
        self._answer_counter = 0
        self._yes_count = 0
        self._no_count = 0
    def to_answer(self):
        self._answer_counter += 1
        if self._answer_counter % 2 == 1:
            self._yes_count += 1
            return "moore-moore"
        else:
            self._no_count += 1
            return "meow-meow"
    def number_yes(self):
        return self._yes_count
    def number_no(self):
        return self._no_count
print("Пример 1:")
tk = Talking('Pussy')
print(tk.to_answer())
print(tk.to_answer())
print(tk.to_answer())
print(f'{tk.name} says "yes" {tk.number_yes()} times, "no" {tk.number_no()} times')
print("\nПример 2:")
tk = Talking('Pussy')
tk1 = Talking('Barsik')
print(tk.to_answer())
print(tk1.to_answer())
print(tk1.to_answer())
print(tk1.to_answer())
print(f'{tk.name} says "yes" {tk.number_yes()} times, "no" {tk.number_no()} times')
print(f'{tk1.name} says "yes" {tk1.number_yes()} times, "no" {tk1.number_no()} times')