from datetime import date
class Client:
    def __init__(self, client_code, full_name, deposit_date, deposit_amount, interest_rate):
        self.client_code = client_code
        self.full_name = full_name
        self.deposit_date = deposit_date
        self.deposit_amount = deposit_amount
        self.interest_rate = interest_rate
    def __str__(self):
        return (f"Код: {self.client_code}, ФИО: {self.full_name}, "
                f"Дата открытия: {self.deposit_date}, "
                f"Сумма вклада: {self.deposit_amount} руб., "
                f"Процентная ставка: {self.interest_rate}%")
class Bank:
    def __init__(self):
        self.client_base = []
    def add_client(self, client):
        if isinstance(client, Client):
            self.client_base.append(client)
    def show_by_money(self, money):
        result = [client for client in self.client_base if client.deposit_amount > money]
        if not result:
            print(f"Нет клиентов с суммой вклада больше {money} руб.")
        else:
            print(f"Клиенты с суммой вклада больше {money} руб.:")
            for client in result:
                print(client)
    def show_by_code(self, code):
        for client in self.client_base:
            if client.client_code == code:
                print("Найден клиент:")
                print(client)
                return
    def show_by_proc(self, proc):
        result = [client for client in self.client_base if client.interest_rate > proc]
        if not result:
            print(f"Нет клиентов с процентной ставкой выше {proc}%")
        else:
            print(f"Клиенты с процентной ставкой выше {proc}%:")
            for client in result:
                print(client)
    def __str__(self):
        return "\n".join(str(client) for client in self.client_base)
if __name__ == "__main__":
    bank = Bank()
    bank.add_client(Client(1, "Гойда Прайм Зетникович", date(2020, 5, 15), 500000, 5.5))
    bank.add_client(Client(2, "Поляков Николай Владимирович", date(2021, 3, 10), 1000000, 6.2))
    bank.add_client(Client(3, "Александр Байтов Викторович", date(2022, 1, 20), 300000, 4.8))
    print("Все клиенты банка:")
    print(bank)
    print("\nПоиск клиентов с суммой вклада > 400000 руб.:")
    bank.show_by_money(400000)
    print("\nПоиск клиента с кодом 2:")
    bank.show_by_code(2)
    print("\nПоиск клиентов с процентной ставкой > 5%:")
    bank.show_by_proc(5)