import math

class RightTriangle:
    def __init__(self, a, b):
        if a <= 0 or b <= 0:
            raise ValueError("Длины сторон должны быть положительными числами")
        self.a = a
        self.b = b
        self.c = math.sqrt(a**2 + b**2) 
    def resize_side(self, side_name, percent):
        if side_name not in ['a', 'b', 'c']:
            raise ValueError("Неверное имя стороны. Допустимые значения: 'a', 'b', 'c'")
        old_value = getattr(self, side_name)
        new_value = old_value * (1 + percent / 100)
        if new_value <= 0:
            raise ValueError("Новая длина стороны должна быть положительной")
        setattr(self, side_name, new_value)
        if side_name in ['a', 'b']:
            self.c = math.sqrt(self.a**2 + self.b**2)
        else:
            ratio = self.c / old_value
            self.a *= ratio
            self.b *= ratio
    def circumradius(self):
        return self.c / 2
    def perimeter(self):
        return self.a + self.b + self.c
    def angles(self):
        alpha = math.degrees(math.atan(self.a / self.b))
        beta = 90 - alpha
        gamma = 90
        return (alpha, beta, gamma)
    def __str__(self):
        return f"Прямоугольный треугольник с катетами {self.a:.2f} и {self.b:.2f}, гипотенузой {self.c:.2f}"
if __name__ == "__main__":
    try:
        triangle = RightTriangle(3, 4)
        print(triangle)
        print(f"Периметр: {triangle.perimeter():.2f}")
        print(f"Радиус описанной окружности: {triangle.circumradius():.2f}")
        angles = triangle.angles()
        print(f"Углы: {angles[0]:.2f}°, {angles[1]:.2f}°, {angles[2]:.2f}°")
        triangle.resize_side('a', 50)
        print("\nПосле увеличения катета a на 50%:")
        print(triangle)
        triangle.resize_side('c', -20)
        print("\nПосле уменьшения гипотенузы на 20%:")
        print(triangle)
    except ValueError as e:
        print(f"Ошибка: {e}")