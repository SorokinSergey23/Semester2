class Snow:
    def __init__(self, count=0):
        self.count = count
    def __add__(self, n):
        return Snow(self.count + n)
    def __sub__(self, n):
        return Snow(max(0, self.count - n))
    def __mul__(self, n):
        return Snow(self.count * n)
    def __truediv__(self, n):
        return Snow(max(0, int(self.count / n)))
    def makeSnow(self, snowflakes_per_row):
        if snowflakes_per_row <= 0 or self.count <= 0:
            return ""
        full_rows = self.count // snowflakes_per_row
        remainder = self.count % snowflakes_per_row
        rows = ["*" * snowflakes_per_row for _ in range(full_rows)]
        if remainder > 0:
            rows.append("*" * remainder)
        return "\n".join(rows)
    def __str__(self):
        return f"Количество снежинок: {self.count}"
if __name__ == "__main__":
    snow = Snow(12)
    print(snow)
    print("\n1. Арифметические операции:")
    snow = snow + 5
    print("После добавления 5:", snow)
    snow = snow - 3
    print("После вычитания 3:", snow)
    snow = snow * 2
    print("После умножения на 2:", snow)
    snow = snow / 3
    print("После деления на 3:", snow)
    print("\n2. Генерация снежинок (5 в ряд):")
    print(snow.makeSnow(5))
    print("\n3. Генерация снежинок (3 в ряд):")
    print(snow.makeSnow(3))
    print("\n4. Генерация снежинок (7 в ряд):")
    print(snow.makeSnow(7))
    print("\n5. Проверка с нулевым количеством снежинок:")
    zero_snow = Snow(0)
    print(zero_snow.makeSnow(5))