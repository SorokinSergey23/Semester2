from tkinter import *
from tkinter import ttk
root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")
btn = ttk.Button(text="Click me")
btn.place(x=20, y=30)
root.mainloop()