from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("300x200")

editor = Text(height=10)
editor.pack(anchor=N, fill=BOTH)

def delete_text():
    editor.delete("1.0", END)

ttk.Button(text="Clear", command=delete_text).pack(side=BOTTOM)

root.mainloop()