from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

char_editor = Text(height=5, wrap="char")
char_editor.pack(anchor=N, fill=X)

word_editor = Text(height=5, wrap="word")
word_editor.pack(anchor=S, fill=X)

root.mainloop()