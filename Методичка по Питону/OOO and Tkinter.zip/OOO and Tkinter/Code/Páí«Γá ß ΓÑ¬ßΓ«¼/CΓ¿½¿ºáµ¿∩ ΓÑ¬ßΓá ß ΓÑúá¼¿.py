from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

editor = Text(wrap="none")
editor.pack(expand=1, fill=BOTH)

editor.insert("1.0", "Hello ")
editor.tag_add("highlightline", "1.0", "1.2")
editor.insert("end", "World", "highlightline")
editor.insert("end", "\nHello All!")

editor.tag_configure("highlightline", background="#ccc", foreground="red", font="TkFixedFont", relief="raised")

root.mainloop()