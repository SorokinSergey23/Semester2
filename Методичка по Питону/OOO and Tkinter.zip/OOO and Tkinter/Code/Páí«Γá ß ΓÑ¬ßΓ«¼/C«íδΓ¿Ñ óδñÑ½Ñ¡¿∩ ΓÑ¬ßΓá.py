from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def on_modified(event):
    label["text"] = editor.selection_get()

editor = Text(height=8)
editor.pack(fill=X)
editor.bind("<<Selection>>", on_modified)

label = ttk.Label()
label.pack(anchor=NW)

root.mainloop()