from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

editor = Text()
editor.pack(expand=1, fill=BOTH)

python_img = PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\pepe.png")
editor.image_create("1.0", image=python_img)

root.mainloop()