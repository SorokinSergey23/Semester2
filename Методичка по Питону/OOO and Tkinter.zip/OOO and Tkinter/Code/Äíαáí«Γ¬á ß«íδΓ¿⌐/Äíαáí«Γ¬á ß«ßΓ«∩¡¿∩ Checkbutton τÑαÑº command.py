from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showinfo

def checkbutton_changed():
    showinfo(title="Info", message="Включено" if enabled.get() else "Отключено")

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

enabled = IntVar()
enabled_checkbutton = ttk.Checkbutton(text="Включить", variable=enabled, command=checkbutton_changed)
enabled_checkbutton.pack(padx=6, pady=6, anchor=NW)

root.mainloop()