from tkinter import *
from tkinter import ttk

def check(*args):
    if name.get() == "admin":
        result.set("Запрещенное имя")
    else:
        result.set("Норма")

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

name = StringVar()
result = StringVar()

name_entry = ttk.Entry(textvariable=name)
name_entry.pack(padx=5, pady=5, anchor=NW)

check_label = ttk.Label(textvariable=result)
check_label.pack(padx=5, pady=5, anchor=NW)

name.trace_add("write", check)
root.mainloop()