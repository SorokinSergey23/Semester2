from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

label = ttk.Label(text="Hello METANIT.COM", font=("Arial", 14))
label.pack()

root.mainloop()