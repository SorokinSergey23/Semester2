from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

lang = StringVar(value="Java")  
languages = ["Python", "Java", "JavaScript", "C#"]

for lang_name in languages:
    ttk.Radiobutton(
        text=lang_name,
        value=lang_name,
        variable=lang
    ).pack(anchor=NW, padx=6, pady=6)

root.mainloop()