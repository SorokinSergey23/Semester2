from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

lang = StringVar()
logos = {
    "Python": PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\pepe.png"),
    "Java": PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\jjj.png")
}

for name, img in logos.items():
    ttk.Radiobutton(
        text=name,
        image=img,
        compound="top",
        variable=lang,
        value=name
    ).pack(anchor=NW, padx=6, pady=6)

root.mainloop()