from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

languages = ["Python", "Java", "C#", "JavaScript"]
listbox = Listbox(selectmode=EXTENDED)
for item in languages:
    listbox.insert(END, item)
listbox.pack(fill=BOTH, expand=True)

root.mainloop()