from tkinter import *
from tkinter import ttk

def on_select(event):
    selected = combobox.get()
    label.config(text=f"Выбрано: {selected}")

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

languages = ["Python", "Java", "C#", "JavaScript"]
combobox = ttk.Combobox(values=languages, state="readonly")
combobox.bind("<<ComboboxSelected>>", on_select)
combobox.pack(pady=10)

label = ttk.Label()
label.pack()

root.mainloop()