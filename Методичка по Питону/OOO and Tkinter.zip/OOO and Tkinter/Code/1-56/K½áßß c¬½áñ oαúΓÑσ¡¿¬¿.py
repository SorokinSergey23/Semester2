class Equipment:
    def __init__(self, name, make, year):
        self.name = name
        self.make = make
        self.year = year
    
    def action(self):
        return 'Не определено'
    
    def __str__(self):
        return f'{self.name} {self.make} {self.year}'

class Printer(Equipment):
    def __init__(self, series, name, make, year):
        super().__init__(name, make, year)
        self.series = series
    
    def __str__(self):
        return f'{self.name} {self.series} {self.make} {self.year}'
    
    def action(self):
        return 'Печатает'

class Scaner(Equipment):
    def __init__(self, name, make, year):
        super().__init__(name, make, year)
    
    def action(self):
        return 'Сканирует'

class Xerox(Equipment):
    def __init__(self, name, make, year):
        super().__init__(name, make, year)
    
    def action(self):
        return 'Копирует'