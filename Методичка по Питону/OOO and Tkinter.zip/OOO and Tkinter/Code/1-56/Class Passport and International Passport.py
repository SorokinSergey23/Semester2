class Passport:
    def __init__(self, first_name, last_name, country, date_of_birth, numb_of_pasport):
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.country = country
        self.numb_of_pasport = numb_of_pasport
    
    def PrintInfo(self):
        print(f"\nFullname: {self.first_name} {self.last_name}")
        print(f"Date of birth: {self.date_of_birth}")
        print(f"County: {self.country}")
        print(f"Passport number: {self.numb_of_pasport}")

class ForeignPassport(Passport):
    def __init__(self, first_name, last_name, country, date_of_birth, numb_of_pasport, visa):
        super().__init__(first_name, last_name, country, date_of_birth, numb_of_pasport)
        self.visa = visa
    
    def PrintInfo(self):
        super().PrintInfo()
        print(f"Visa: {self.visa}")