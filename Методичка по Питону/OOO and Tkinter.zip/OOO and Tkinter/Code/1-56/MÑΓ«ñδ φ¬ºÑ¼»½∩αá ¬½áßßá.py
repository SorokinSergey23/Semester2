class PhoneWithMethods:
    def __init__(self, color, model):
        self.color = color
        self.model = model
    
    def check_sim(self, mobile_operator):
        if self.model == 'I785' and mobile_operator == 'MTS':
            print('Your mobile operator is MTS')