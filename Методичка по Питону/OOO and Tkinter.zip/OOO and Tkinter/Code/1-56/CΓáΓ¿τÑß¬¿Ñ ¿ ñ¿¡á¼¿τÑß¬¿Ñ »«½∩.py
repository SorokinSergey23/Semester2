class PhoneWithFields:
    default_color = 'Grey'
    default_model = 'C385'
    
    def __init__(self, color, model):
        self.color = color
        self.model = model