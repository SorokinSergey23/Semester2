class Phone:
    pass