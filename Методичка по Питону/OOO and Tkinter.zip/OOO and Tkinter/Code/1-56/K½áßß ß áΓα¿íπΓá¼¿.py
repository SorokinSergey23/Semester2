class PhoneWithAttributes:
    color = 'Grey'
    def turn_on(self):
        pass
    def call(self):
        pass