from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("300x250")

y = 0
direction = -10
btn_height = 40
canvas_height = 200

canvas = Canvas(bg="white", width=250, height=canvas_height)
canvas.pack(anchor=CENTER, expand=1)

def cliked_button():
    global y, direction
    if y >= canvas_height - btn_height or y <= 0: 
        direction = direction * -1
    y += direction
    canvas.coords(btnId, 10, y)

btn = ttk.Button(text="Click", command=cliked_button)
btnId = canvas.create_window(10, y, anchor=NW, window=btn, width=100, height=btn_height)

root.mainloop()