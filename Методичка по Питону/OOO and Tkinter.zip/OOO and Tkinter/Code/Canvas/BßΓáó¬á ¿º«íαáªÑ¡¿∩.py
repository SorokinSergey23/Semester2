from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("300x250")

canvas = Canvas(bg="white", width=250, height=200)
canvas.pack(anchor=CENTER, expand=1)

python_image = PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\pepe.png")
canvas.create_image(10, 10, anchor=NW, image=python_image)

root.mainloop()