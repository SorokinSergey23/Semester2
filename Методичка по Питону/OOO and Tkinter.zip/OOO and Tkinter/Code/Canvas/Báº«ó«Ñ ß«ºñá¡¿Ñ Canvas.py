from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("300x300")

canvas = Canvas(bg="white", width=250, height=250)
canvas.pack(anchor=CENTER, expand=1)

root.mainloop()