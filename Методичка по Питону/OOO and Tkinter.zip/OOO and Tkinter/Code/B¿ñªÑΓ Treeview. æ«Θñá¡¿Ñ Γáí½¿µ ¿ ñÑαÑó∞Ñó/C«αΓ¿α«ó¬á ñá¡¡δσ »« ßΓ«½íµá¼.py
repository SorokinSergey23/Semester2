from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

people = [("Tom", 38, "tom@email.com"), ("Bob", 42, "bob@email.com"), ("Sam", 28, "sam@email.com")]
columns = ("name", "age", "email")

tree = ttk.Treeview(columns=columns, show="headings")
tree.pack(expand=1, fill=BOTH)

def sort(col, reverse):
    items = [(tree.set(k, col), k) for k in tree.get_children("")]
    items.sort(reverse=reverse)
    for index, (_, k) in enumerate(items):
        tree.move(k, "", index)
    tree.heading(col, command=lambda: sort(col, not reverse))

tree.heading("name", text="Имя", anchor=W, command=lambda: sort(0, False))
tree.heading("age", text="Возраст", anchor=W, command=lambda: sort(1, False))
tree.heading("email", text="Email", anchor=W, command=lambda: sort(2, False))

for person in people:
    tree.insert("", END, values=person)

root.mainloop()