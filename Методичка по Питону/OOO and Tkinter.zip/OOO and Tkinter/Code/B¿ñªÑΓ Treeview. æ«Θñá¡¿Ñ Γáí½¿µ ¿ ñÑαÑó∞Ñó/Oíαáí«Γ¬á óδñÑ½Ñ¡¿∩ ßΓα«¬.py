from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

people = [("Tom", 38, "tom@email.com"), ("Bob", 42, "bob@email.com"), ("Sam", 28, "sam@email.com")]
label = ttk.Label()
label.pack(anchor=N, fill=X)

columns = ("name", "age", "email")
tree = ttk.Treeview(columns=columns, show="headings")
tree.pack(expand=1, fill=BOTH)

tree.heading("name", text="Имя")
tree.heading("age", text="Возраст")
tree.heading("email", text="Email")

for person in people:
    tree.insert("", END, values=person)

def item_selected(event):
    selected_items = ""
    for item_id in tree.selection():
        item = tree.item(item_id)
        selected_items += f"{item['values']}\n"
    label["text"] = selected_items

tree.bind("<<TreeviewSelect>>", item_selected)

root.mainloop()