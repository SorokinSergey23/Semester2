from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

tree = ttk.Treeview(show="tree")
tree.pack(expand=1, fill=BOTH)

tree.insert("", END, iid=1, text="Административный отдел", open=True)
tree.insert("", END, iid=2, text="IT-отдел")
tree.insert("", END, iid=3, text="Отдел продаж")

tree.insert(1, END, text="Tom")
tree.insert(2, END, text="Bob")
tree.insert(2, END, text="Sam")

root.mainloop()