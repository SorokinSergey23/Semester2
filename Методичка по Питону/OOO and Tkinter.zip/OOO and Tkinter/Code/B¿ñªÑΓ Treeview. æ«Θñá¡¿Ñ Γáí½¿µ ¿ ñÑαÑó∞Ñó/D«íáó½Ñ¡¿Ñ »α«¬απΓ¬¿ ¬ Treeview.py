from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

root.rowconfigure(0, weight=1)
root.columnconfigure(0, weight=1)

people = [("Tom", 38, "tom@email.com"), ("Bob", 42, "bob@email.com"), ("Sam", 28, "sam@email.com")]
columns = ("name", "age", "email")

tree = ttk.Treeview(columns=columns, show="headings")
tree.grid(row=0, column=0, sticky="nsew")

tree.heading("name", text="Имя")
tree.heading("age", text="Возраст")
tree.heading("email", text="Email")

for person in people:
    tree.insert("", END, values=person)

scrollbar = ttk.Scrollbar(orient=VERTICAL, command=tree.yview)
tree.configure(yscroll=scrollbar.set)
scrollbar.grid(row=0, column=1, sticky="ns")

root.mainloop()