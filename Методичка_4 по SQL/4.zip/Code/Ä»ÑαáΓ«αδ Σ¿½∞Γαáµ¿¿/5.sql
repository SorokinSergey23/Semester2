SELECT * FROM Products
WHERE ProductName LIKE '%Galaxy%';