SELECT * FROM Products
WHERE ProductName LIKE 'G%'
  AND ProductCount > 2;
