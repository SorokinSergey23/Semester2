SELECT * FROM Products
WHERE Manufacturer = 'Samsung'
  AND Price BETWEEN 40000 AND 60000;
