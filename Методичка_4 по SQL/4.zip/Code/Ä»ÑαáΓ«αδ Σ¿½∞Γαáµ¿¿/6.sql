SELECT * FROM Products
WHERE Manufacturer LIKE '%ung';
