SELECT 
    Company, 
    AVG(Price) AS AvgPrice
FROM Products
GROUP BY Company
HAVING AVG(Price) > 50000;