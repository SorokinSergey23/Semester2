SELECT 
    Company, 
    COUNT(*) AS Models, 
    ProductCount
FROM Products
GROUP BY GROUPING SETS(
    (Company),
    (ProductCount)
);