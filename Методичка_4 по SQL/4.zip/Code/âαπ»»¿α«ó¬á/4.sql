SELECT 
    COALESCE(Company, 'Все компании') AS CompanyGroup,
    COALESCE(CAST(ProductCount AS VARCHAR), 'Все количества') AS CountGroup,
    COUNT(*) AS Models,
    SUM(Price) AS TotalPrice
FROM Products
GROUP BY GROUPING SETS(
    (Company),
    (ProductCount),
    ()
);