SELECT FirstName, LastName
FROM Employees
INTERSECT
SELECT FirstName, LastName
FROM Customers;

SELECT FirstName, LastName
FROM Employees
INTERSECT
SELECT FirstName, LastName
FROM Customers
WHERE AccountSum > 2500;

SELECT FirstName, LastName
FROM Employees
INTERSECT
SELECT FirstName, LastName
FROM Customers
ORDER BY LastName;