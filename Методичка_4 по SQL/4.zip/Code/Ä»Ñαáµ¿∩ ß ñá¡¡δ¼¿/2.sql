INSERT INTO Products (Id, ProductName, Manufacturer, ProductCount, Price) 
VALUES (1, 'Galaxy S9', 'Samsung', 4, 63000);

INSERT INTO Products (ProductName, Manufacturer, ProductCount, Price) 
VALUES ('Galaxy S9', 'Samsung', 4, 63000);