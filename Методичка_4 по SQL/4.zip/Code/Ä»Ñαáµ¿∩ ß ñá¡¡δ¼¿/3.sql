INSERT INTO Products
(ProductName, Manufacturer, ProductCount, Price)
VALUES('Desire 12', 'HTC', 8, 21000)
RETURNING Id;