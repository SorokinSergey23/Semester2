SELECT ProductName, ProductCount * Price AS TotalSum
FROM Products
ORDER BY TotalSum;

SELECT ProductName, Manufacturer
FROM Products
ORDER BY Manufacturer DESC;

SELECT ProductName, Manufacturer
FROM Products
ORDER BY Manufacturer ASC;

SELECT ProductName, Price, Manufacturer
FROM Products
ORDER BY Manufacturer, ProductName;

SELECT ProductName, Price, Manufacturer
FROM Products
ORDER BY Manufacturer ASC, ProductName DESC;