SELECT * FROM Products
ORDER BY ProductCount;