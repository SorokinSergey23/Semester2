SELECT *
FROM Products
WHERE Price > (SELECT AVG(Price) FROM Products);

SELECT 
    ProductName,
    Company,
    Price,
    (SELECT AVG(Price) FROM Products AS SubProds
     WHERE SubProds.Company = Prods.Company) AS AvgCompanyPrice
FROM Products AS Prods
WHERE Price > (SELECT AVG(Price) FROM Products AS SubProds
               WHERE SubProds.Company = Prods.Company);