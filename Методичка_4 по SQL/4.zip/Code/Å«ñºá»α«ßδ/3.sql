INSERT INTO Orders(ProductId, CustomerId, CreatedAt, ProductCount, Price) VALUES
(
    (SELECT Id FROM Products WHERE ProductName='Galaxy S9'),
    (SELECT Id FROM Customers WHERE FirstName='Tom'),
    '2017-07-11',
    2,
    (SELECT Price FROM Products WHERE ProductName='Galaxy S9')
),
(
    (SELECT Id FROM Products WHERE ProductName='iPhone 8'),
    (SELECT Id FROM Customers WHERE FirstName='Tom'),
    '2017-07-13',
    1,
    (SELECT Price FROM Products WHERE ProductName='iPhone 8')
),
(
    (SELECT Id FROM Products WHERE ProductName='iPhone 8'),
    (SELECT Id FROM Customers WHERE FirstName='Bob'),
    '2017-07-11',
    1,
    (SELECT Price FROM Products WHERE ProductName='iPhone 8')
);