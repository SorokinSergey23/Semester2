ALTER TABLE Customers
ADD CHECK (Age > 0);

ALTER TABLE Customers
ADD PRIMARY KEY (Id);

ALTER TABLE Customers
ADD UNIQUE (Email);

ALTER TABLE Customers
ADD CONSTRAINT phone_unique UNIQUE (Phone);

ALTER TABLE Customers
DROP CONSTRAINT phone_unique;

ALTER TABLE Customers
RENAME COLUMN Address TO City;

ALTER TABLE Customers
RENAME TO Users;