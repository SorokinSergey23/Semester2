CREATE TABLE Customers
(
    id SERIAL,
    FirstName CHARACTER VARYING(39),
    LastName CHARACTER VARYING(39),
    Email CHARACTER VARYING(39),
    Age INTEGER,
    PRIMARY KEY(id)
);
