CREATE TABLE Customers
(
    Id SERIAL,
    Age INTEGER,
    FirstName CHARACTER VARYING(20) NOT NULL,
    LastName CHARACTER VARYING(20) NOT NULL,
    Email CHARACTER VARYING(20),
    Phone CHARACTER VARYING(20),
    CONSTRAINT customer_id PRIMARY KEY(Id),
    CONSTRAINT customer_age_check CHECK(Age > 0 AND Age < 100),
    CONSTRAINT customer_email_key UNIQUE(Email),
    CONSTRAINT customer_phone_key UNIQUE(Phone)
);