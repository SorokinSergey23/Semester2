SELECT * FROM Products 
WHERE Manufacturer = 'Apple';

SELECT * FROM Products 
WHERE Price < 39000;

SELECT * FROM Products 
WHERE Price * ProductCount > 90000;