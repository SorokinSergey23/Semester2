SELECT * FROM Products 
WHERE Manufacturer = 'Samsung' OR Price > 30000 AND ProductCount > 2;

SELECT * FROM Products 
WHERE (Manufacturer = 'Samsung' OR Price > 30000) AND ProductCount > 2;