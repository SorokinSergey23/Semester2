UPDATE Products
SET Price = Price + 3000;

SELECT * FROM Products;

UPDATE Products
SET Manufacturer = 'Samsung Inc.'
WHERE Manufacturer = 'Samsung';

SELECT * FROM Products;