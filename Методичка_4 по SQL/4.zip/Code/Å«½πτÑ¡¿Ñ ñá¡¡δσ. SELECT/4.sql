SELECT * FROM Products 
WHERE ProductCount IS NULL;

SELECT * FROM Products 
WHERE ProductCount IS NOT NULL;