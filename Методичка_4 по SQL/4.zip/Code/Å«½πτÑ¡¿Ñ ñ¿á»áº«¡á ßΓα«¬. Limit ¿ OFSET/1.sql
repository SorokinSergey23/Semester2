SELECT * FROM Products
ORDER BY ProductName
LIMIT 4;
