SELECT * FROM Products
ORDER BY ProductName
OFFSET 2;