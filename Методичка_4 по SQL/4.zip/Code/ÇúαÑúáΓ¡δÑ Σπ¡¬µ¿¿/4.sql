SELECT 
    COUNT(*) AS ProdCount,
    SUM(ProductCount) AS TotalUnits,
    MIN(Price) AS MinPrice,
    MAX(Price) AS MaxPrice,
    AVG(Price) AS AvgPrice
FROM Products;
