SELECT AVG(Price) AS Average_Price FROM Products;

SELECT AVG(Price) FROM Products WHERE Company='Apple';

SELECT AVG(Price * ProductCount) FROM Products;

SELECT COUNT(*) FROM Products;

SELECT COUNT(*) FROM Products WHERE IsDiscounted = true;
