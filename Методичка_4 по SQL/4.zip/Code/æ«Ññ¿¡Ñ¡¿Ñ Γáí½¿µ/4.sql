SELECT * FROM Orders, Customers;

SELECT * 
FROM Orders, Customers 
WHERE Orders.CustomerId = Customers.Id;

SELECT *
FROM Orders
JOIN Customers ON Orders.CustomerId = Customers.Id;
