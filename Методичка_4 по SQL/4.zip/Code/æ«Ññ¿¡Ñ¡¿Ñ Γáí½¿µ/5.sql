SELECT 
    Customers.FirstName, 
    Products.ProductName, 
    Orders.CreatedAt,
    Orders.ProductCount,
    Orders.Price
FROM Orders
JOIN Customers ON Orders.CustomerId = Customers.Id
JOIN Products ON Orders.ProductId = Products.Id;