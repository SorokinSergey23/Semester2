SELECT FirstName, LastName FROM Customers
UNION
SELECT Id, LastName FROM Employees;

SELECT FirstName, LastName, AccountSum + AccountSum * 0.1 AS TotalSum FROM Customers WHERE AccountSum < 3000
UNION
SELECT FirstName, LastName, AccountSum + AccountSum * 0.3 AS TotalSum FROM Customers WHERE AccountSum >= 3000
ORDER BY TotalSum DESC;