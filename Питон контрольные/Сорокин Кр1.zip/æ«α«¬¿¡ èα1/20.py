s = input()
for i in range(len(s) - 1, -1, -1):
    if i % 3 == 0:
        s = s[:i] + s[i+1:]
print(s)