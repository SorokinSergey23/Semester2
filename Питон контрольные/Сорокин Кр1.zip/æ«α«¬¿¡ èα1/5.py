M = int(input('Введите положительное число: '))
while M <= 0:
    M = int(input('Введите положительное число: '))
empt = list()
k = 0
while k != M:
    a = input('Введите строчку: ')
    empt.append(a.count(' '))
    k += 1
k = 1
for elem in empt:
    print('В строке: ' + str(k) + ', количество пробелов: ' + str(elem))
    k += 1