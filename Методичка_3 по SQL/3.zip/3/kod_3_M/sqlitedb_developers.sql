create_table_query = 
    CREATE TABLE IF NOT EXISTS sqlitedb_developers (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    joining_date DATE NOT NULL,
    salary REAL NOT NULL
);